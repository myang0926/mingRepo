package utils;

public class CurrentUserUtils {

    public enum Keys{userId, userName,LdapId}
}
